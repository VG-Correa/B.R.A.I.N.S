import os
os.system('clear')
from datetime import datetime


bd = open('bd.txt','r')
bd = bd.readlines()

dic = {}

for item in bd:
    item = item.rstrip()
    if dic.get(item):
        dic[item] += 1
    else:
        dic[item] = 1
        
total = sum(dic.values())
acumulada = 0

for item in dic:
    frequencia = round((dic[item]/total) * 100 ,2)
    acumulada += frequencia
    dic[item] = {"qtd":dic[item],"Frequência": frequencia, "Acumulado":acumulada}

sort = sorted(dic.items(), key=lambda x: x[1]['qtd'] ,reverse=True)

final = {}

for item in sort:
    
    final[item[0]] = {"qtd": item[1]['qtd'],'Frequência': item[1]['Frequência'], 'Acumulado': item[1]['Acumulado'] }

texto = ""

now = str(datetime.now())
  
print('Análise de Pareto ----', now )
texto = texto + "Análise de Pareto ---- " + now + '\n'
print("="*91)
texto = texto + "="*91 + "\n"
print(f'{"Descrição":<50} | {"Quantidade":<10} | {"Frequência":<10} | {"Acumulado":<10} |')
texto = texto + f'{"Descrição":<50} | {"Quantidade":<10} | {"Frequência":<10} | {"Acumulado":<10} |\n'

for item in final:
    
    categoria = f'{item:<50}'
    qtd = f'{final[item]["qtd"]:<10}'
    frequencia = f'{str(final[item]["Frequência"])+"%":<10}'
    acumulado = f'{str(final[item]["Acumulado"])+"%":<10}'
    
    print(f'{categoria} | {qtd} | {frequencia} | {acumulado} |')
    texto = texto + f'{categoria} | {qtd} | {frequencia} | {acumulado} |\n'
    
print("="*91)
texto = texto + "="*91 + "\n"

final = open('Análise de Pareto.txt','a')

final.write(texto)