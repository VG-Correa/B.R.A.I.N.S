

string = "123"

print("1" in string)